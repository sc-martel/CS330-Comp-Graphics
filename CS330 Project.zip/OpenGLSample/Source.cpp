﻿#include <iostream>             // cout, cerr
#include <cstdlib>              // EXIT_FAILURE
#include <GL/glew.h>            // GLEW library
#include <GLFW/glfw3.h>         // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "camera.h" // Camera class

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h" // Image loading Utility functions

using namespace std; // Standard namespace

/**
    Author: Scott Martel
    Date: 02/21/2024

    CS-330 7-1 Final Project
*/


/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Define PI constant
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "7-1 Project Scott Martel"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Shader program
    GLuint gProgramId;

    // camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 6.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void URender();
void UDestroyMesh(GLMesh& mesh);
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void CreateCylinder(GLMesh& mesh, float radius, float height, int numSlices);
void CreateTorus(GLMesh& mesh, float torusRadius, float tubeRadius, int numSides, int numRings);
void CreateCap(GLMesh& mesh, float radius, float height, int numSlices);
void CreatePyramid(GLMesh& mesh, float baseSize, float height);
void CreatePlane(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void flipImageVertically(unsigned char* image, int width, int height, int channels);
void CreateSphere(GLMesh& mesh, float radius, int numSectors, int numStacks);
void CreateCube(GLMesh& mesh);

/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;  // Vertex data from Vertex Attrib Pointer 0
    layout(location = 1) in vec2 texCoords; // Texture coordinate data from Vertex Attrib Pointer 1
    layout(location = 2) in vec3 normal;    // Normal data from Vertex Attrib Pointer 2

    out vec2 TexCoords;
    out vec3 FragPos; // Pass fragment position to fragment shader
    out vec3 Normal; 

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main() {
        FragPos = vec3(model * vec4(position, 1.0));
        Normal = mat3(transpose(inverse(model))) * normal;
        TexCoords = texCoords;
      
        gl_Position = projection * view * vec4(FragPos, 1.0); // Transform vertices to clip coordinates
    }
);

/* Fragment Shader Source Code */
const GLchar* fragmentShaderSource = GLSL(440,
    in vec3 Normal; // Normal vector from vertex shader
    in vec3 FragPos; // Fragment position from vertex shader
    in vec2 TexCoords; // Texture coordinates from vertex shader

    uniform vec3 lightPos; // Light position in world space
    uniform vec3 viewPos; // Camera/view position
    uniform vec3 lightColor; // Color of the light

    // Second light properties
    uniform vec3 lightPos2; // Second light position in world space
    uniform vec3 lightColor2; // Second light color

    uniform sampler2D texture1;
    uniform sampler2D texture2;
    uniform sampler2D texture3;
    uniform int textureSelector;

    out vec4 fragmentColor; // Output color of the fragment

    void main() {
        // Ambient lighting component
        float ambientStrength = 0.9;
        vec3 ambient = ambientStrength * lightColor;

        // Diffuse lighting component
        vec3 norm = normalize(Normal);
        vec3 lightDir = normalize(lightPos - FragPos);
        float diff = max(dot(norm, lightDir), 0.0);
        vec3 diffuse = diff * lightColor;

        // Specular lighting component
        float specularStrength = 0.8;
        vec3 viewDir = normalize(viewPos - FragPos);
        vec3 reflectDir = reflect(-lightDir, norm);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32);
        vec3 specular = specularStrength * spec * lightColor;

        // Second light calculations (same as the first light)
        vec3 ambient2 = ambientStrength * lightColor2;
        vec3 lightDir2 = normalize(lightPos2 - FragPos);
        float diff2 = max(dot(norm, lightDir2), 0.0);
        vec3 diffuse2 = diff2 * lightColor2;
        vec3 reflectDir2 = reflect(-lightDir2, norm);
        float spec2 = pow(max(dot(viewDir, reflectDir2), 0.0), 32);
        vec3 specular2 = specularStrength * spec2 * lightColor2;


        // Selecting texture color based on textureSelector
        vec4 texColor = vec4(1.0); // Default color
        if (textureSelector == 0) {
            texColor = texture(texture1, TexCoords);
        }
        else if (textureSelector == 1) {
            texColor = texture(texture2, TexCoords);
        }
        else if (textureSelector == 2) {
            texColor = texture(texture3, TexCoords);
        }
       
        // Combine the results of both lights
        vec3 result = (ambient + diffuse + specular + ambient2 + diffuse2 + specular2) * texColor.rgb;
        fragmentColor = vec4(result, texColor.a); // Use alpha from texture
    }
);

// Global variables for mesh data
GLMesh gCylinderMesh;
GLMesh gTorusMesh;
GLMesh gCapMesh;
GLMesh gPyramidMesh;
GLMesh gPlaneMesh;
GLMesh gCylinder2Mesh;     // Cylinder for coffee
GLMesh gSphereMesh;        // Sphere for apple
GLMesh gCubeMesh;          // Cube for ice cream box

// Height of the cylinder
float cylinderHeight;
// Minor radius of the torus
float torusMinorRadius;
// Height of cap
float capHeight;
// Pyramid height
float pyramidHeight;

// Parameters for the second cofee cylinder 
float cylinder2Radius = 0.7f;
float cylinder2Height = 1.5f;
int cylinder2Slices = 20;

// Global Booleans for perspective view
bool isPerspective = true;
bool pKeyWasPressed = false;

// Global variables for textures
GLuint cylinderTextureID;  // Cylinder for hot sauce
GLuint torusTextureID;
GLuint capTextureID;
GLuint woodFloorTextureID;
GLuint coffeeTextureID; // Texture ID for coffee cylinder
// Global variable for the new texture
GLuint iceCreamTextureID;

glm::vec3 lightPos(1.2f, 1.0f, 2.0f); // Position of a point light
glm::vec3 lightDirection(-0.2f, -1.0f, -0.3f); // Direction for the directional light
glm::vec3 lightColor(1.0f, 0.95f, 0.8f); // Warm white light


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Parameters for the hot sauce cylinder
    float cylinderRadius = 0.4f;
    float cylinderHeight = 1.5f;
    int cylinderSlices = 20;

    // Parameters for the torus
    float torusMajorRadius = 0.3f;
    float torusMinorRadius = 0.1f;
    int torusNumSides = 100;
    int torusNumRings = 100;

    // Parameters for the cap
    float capRadius = 0.2f;
    capHeight = 0.3f;
    int capSlices = 20;

    // Parameters for tip of cap
    float pyramidBaseSize = 0.2f;
    pyramidHeight = 0.5f;

    // Parameters for apple sphere
    float sphereRadius = 0.4;
    int sphereSectors = 36;
    int sphereStacks = 18;

    // Parameters for the ice cream box rectangle
    float rectangleWidth = 1.0f;
    float rectangleHeight = 2.0f;

    // Initialize plane mesh
    CreatePlane(gPlaneMesh);

    // Create the hot sauce bottle
    // Create the pyramid mesh
    CreatePyramid(gPyramidMesh, pyramidBaseSize, pyramidHeight);
    // Create the cap mesh
    CreateCap(gCapMesh, capRadius, capHeight, capSlices);
    // Create the torus mesh
    CreateTorus(gTorusMesh, torusMajorRadius, torusMinorRadius, torusNumSides, torusNumRings);
    // Create the cylinder mesh
    CreateCylinder(gCylinderMesh, cylinderRadius, cylinderHeight, cylinderSlices);

    // Create the second cylinder mesh for the coffee container
    CreateCylinder(gCylinder2Mesh, cylinder2Radius, cylinder2Height, cylinder2Slices);

    // Create the sphere for the apple
    CreateSphere(gSphereMesh, sphereRadius, sphereSectors, sphereStacks);

    // Create the cube for the ice cream box
    CreateCube(gCubeMesh);


    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    if (!UCreateTexture("cylinder_texture.jpg", cylinderTextureID)) {
        cerr << "Failed to load cylinder texture" << endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture("torus_texture.jpg", torusTextureID)) {
        cerr << "Failed to load torus texture" << endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture("cap_texture.jpg", capTextureID)) {
        cerr << "Failed to load cap texture" << endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture("wood_floor_texture.jpg", woodFloorTextureID)) {
        cerr << "Failed to load wood floor texture" << endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture("coffee_texture.jpg", coffeeTextureID)) {
        cerr << "Failed to load coffee texture" << endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture("ice_cream_texture.jpg", iceCreamTextureID)) {
        cerr << "Failed to load ice cream texture" << endl;
        return EXIT_FAILURE;
    }

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gCylinderMesh);
    UDestroyMesh(gTorusMesh);
    UDestroyMesh(gCapMesh);
    UDestroyMesh(gPyramidMesh);
    UDestroyMesh(gCylinder2Mesh);
    UDestroyMesh(gSphereMesh);
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gCubeMesh);

    // Release texture
    UDestroyTexture(coffeeTextureID);
    UDestroyTexture(iceCreamTextureID);

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;
    static bool pKeyWasPressed = false;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    // Debounced toggle between perspective and orthographic view
    bool pKeyPressed = glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS;
    if (pKeyPressed && !pKeyWasPressed) {
        isPerspective = !isPerspective;
        pKeyWasPressed = true; // Mark the key as pressed
    }
    else if (!pKeyPressed) {
        pKeyWasPressed = false; // Reset the flag when key is released
    }
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

void URender() {
    // Enable depth testing to ensure correct rendering order
    glEnable(GL_DEPTH_TEST);

    // Clear the color and depth buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Black background
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Use the shader program
    glUseProgram(gProgramId);

    // Pass light and view properties to the shader
    glUniform3fv(glGetUniformLocation(gProgramId, "lightColor"), 1, glm::value_ptr(lightColor));
    glUniform3fv(glGetUniformLocation(gProgramId, "lightPos"), 1, glm::value_ptr(lightPos));
    glUniform3fv(glGetUniformLocation(gProgramId, "viewPos"), 1, glm::value_ptr(gCamera.Position));

    // Second light properties
    glm::vec3 lightPos2 = glm::vec3(-1.2f, -1.0f, -2.0f); // Position of the second light
    glm::vec3 lightColor2 = glm::vec3(1.0f, 0.5f, 0.0f); // Orange color for the second light
    glUniform3fv(glGetUniformLocation(gProgramId, "lightColor2"), 1, glm::value_ptr(lightColor2));
    glUniform3fv(glGetUniformLocation(gProgramId, "lightPos2"), 1, glm::value_ptr(lightPos2));

    // Calculate and pass the view and projection matrices to the shader
    glm::mat4 view = gCamera.GetViewMatrix();
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "view"), 1, GL_FALSE, glm::value_ptr(view));

    glm::mat4 projection;
    if (isPerspective) {
        projection = glm::perspective(glm::radians(gCamera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else {
        projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
    }
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

    // Texture selection uniform location
    GLint textureSelectorLoc = glGetUniformLocation(gProgramId, "textureSelector");

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Model matrix for each object
    glm::mat4 model;

    // Render the plane
    model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.75f, 0.0f));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(model));
    glUniform1i(textureSelectorLoc, 0);
    glBindTexture(GL_TEXTURE_2D, woodFloorTextureID);
    glBindVertexArray(gPlaneMesh.vao);
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Render the cylinder with its texture
    model = glm::mat4(1.0f); // Reset model matrix for the cylinder
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(model));
    glUniform1i(textureSelectorLoc, 0); // Select texture1 for the cylinder
    glBindTexture(GL_TEXTURE_2D, cylinderTextureID); // Bind the cylinder's texture
    glBindVertexArray(gCylinderMesh.vao);
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Render the torus
    model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.75f, 0.0f)); // Position the torus
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(model));
    glUniform1i(textureSelectorLoc, 1); 
    glBindTexture(GL_TEXTURE_2D, torusTextureID); // Bind the torus's texture
    glBindVertexArray(gTorusMesh.vao);
    glDrawElements(GL_TRIANGLES, gTorusMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Render the cap on top of the torus
    model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.9f, 0.0f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, capTextureID); // Use the cap's texture
    glUniform1i(glGetUniformLocation(gProgramId, "texture1"), 0); // Texture unit 0
    glBindVertexArray(gCapMesh.vao);
    glDrawElements(GL_TRIANGLES, gCapMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Render the pyramid on top of the cap
    model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindVertexArray(gPyramidMesh.vao);
    glDrawElements(GL_TRIANGLES, gPyramidMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Render the second cylinder for the coffee container
    model = glm::translate(glm::mat4(1.0f), glm::vec3(1.9f, 0.0f, 0.8f));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(model));
    glUniform1i(textureSelectorLoc, 0);
    glBindTexture(GL_TEXTURE_2D, coffeeTextureID);
    glBindVertexArray(gCylinder2Mesh.vao);
    glDrawElements(GL_TRIANGLES, gCylinder2Mesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Render the sphere for the apple
    model = glm::translate(glm::mat4(1.0f), glm::vec3(0.1f, -0.35f, 2.15f));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(model));
    glUniform1i(textureSelectorLoc, 1);
    glBindTexture(GL_TEXTURE_2D, torusTextureID);
    glBindVertexArray(gSphereMesh.vao);
    glDrawElements(GL_TRIANGLES, gSphereMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Render the cube for the ice cream box
    float scaleWidth = 1.0f;
    float scaleHeight = 1.5f;
    float scaleDepth = 0.5f;
    model = glm::scale(glm::mat4(1.0f), glm::vec3(scaleWidth, scaleHeight, scaleDepth));
    model = glm::translate(model, glm::vec3(-1.5f, 0.0f, 2.0f));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(model));
    glUniform1i(textureSelectorLoc, 0);
    glBindTexture(GL_TEXTURE_2D, iceCreamTextureID);
    glBindVertexArray(gCubeMesh.vao);
    glDrawElements(GL_TRIANGLES, gCubeMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Deactivate the Vertex Array Object after drawing
    glBindVertexArray(0);

    // Swap buffers and poll IO events
    glfwSwapBuffers(gWindow);
}

void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

void CreateCylinder(GLMesh& mesh, float radius, float height, int numSlices) {
    std::vector<GLfloat> vertices;
    std::vector<GLushort> indices;

    // Step angle and texture step
    float angleStep = (2.0f * M_PI) / numSlices;
    float textureStep = 1.0f / numSlices;

    // Define vertices for the cylinder
    for (int i = 0; i <= numSlices; ++i) {
        float angle = i * angleStep;
        float u = i * textureStep;

        // Top circle
        float xTop = radius * cos(angle);
        float zTop = radius * sin(angle);
        vertices.insert(vertices.end(), { xTop, height / 2.0f, zTop, u, 0.0f }); // Top vertex

        // Bottom circle
        float xBottom = xTop; // Same x
        float zBottom = zTop; // Same z
        vertices.insert(vertices.end(), { xBottom, -height / 2.0f, zBottom, u, 1.0f }); // Bottom vertex
    }

    // Create indices for the cylinder
    for (int i = 0; i < numSlices; ++i) {
        int top1 = 2 * i;
        int bottom1 = 2 * i + 1;
        int top2 = 2 * ((i + 1) % (numSlices + 1));
        int bottom2 = 2 * ((i + 1) % (numSlices + 1)) + 1;

        // First triangle (top1, bottom1, top2)
        indices.push_back(top1);
        indices.push_back(bottom1);
        indices.push_back(top2);

        // Second triangle (bottom1, bottom2, top2)
        indices.push_back(bottom1);
        indices.push_back(bottom2);
        indices.push_back(top2);
    }

    // Generate and bind VAO and VBO for the vertices and indices
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), vertices.data(), GL_STATIC_DRAW);

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLushort), indices.data(), GL_STATIC_DRAW);

    // Vertex position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    // Texture coordinate attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Unbind VAO to avoid accidental modifications
    glBindVertexArray(0);
}

void CreateTorus(GLMesh& mesh, float torusRadius, float tubeRadius, int numSides, int numRings) {
    std::vector<GLfloat> vertices;
    std::vector<GLushort> indices;

    for (int i = 0; i < numRings; ++i) {
        float ringAngle = (2.0f * M_PI / numRings) * i;
        glm::vec3 ringCenter = glm::vec3(cos(ringAngle), 0.0f, sin(ringAngle)) * torusRadius;

        for (int j = 0; j < numSides; ++j) {
            float sideAngle = (2.0f * M_PI / numSides) * j;
            glm::vec3 vertexPos = glm::vec3(cos(sideAngle), sin(sideAngle), 0.0f) * tubeRadius;
            vertexPos = glm::vec3(glm::rotate(glm::mat4(1.0f), ringAngle, glm::vec3(0.0f, 1.0f, 0.0f)) * glm::vec4(vertexPos, 1.0f));
            vertexPos += ringCenter;

            // Add the vertex position
            vertices.push_back(vertexPos.x);
            vertices.push_back(vertexPos.y);
            vertices.push_back(vertexPos.z);

            // Add the vertex color
            vertices.push_back(1.0f);  // Red
            vertices.push_back(0.0f);  // Green
            vertices.push_back(0.0f);  // Blue
            vertices.push_back(1.0f);  // Alpha
        }
    }

    // Generating the indices for the torus
    for (int i = 0; i < numRings; ++i) {
        for (int j = 0; j < numSides; ++j) {
            int first = (i * numSides) + j;
            int second = ((i + 1) % numRings) * numSides + j;

            indices.push_back(first);
            indices.push_back(second);
            indices.push_back((first + 1) % numSides + i * numSides);

            indices.push_back(second);
            indices.push_back((second + 1) % numSides + ((i + 1) % numRings) * numSides);
            indices.push_back((first + 1) % numSides + i * numSides);
        }
    }

    // Generate and bind VAO and VBO for the vertices and indices
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), vertices.data(), GL_STATIC_DRAW);

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLushort), indices.data(), GL_STATIC_DRAW);

    // Define vertex attribute pointers for positions and colors
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Unbind to make sure other calls don't accidentally modify this VAO
    glBindVertexArray(0);
}

void CreateCap(GLMesh& mesh, float radius, float height, int numSlices) {
    std::vector<GLfloat> vertices;
    std::vector<GLushort> indices;

    // Define the top circle vertices
    for (int i = 0; i < numSlices; ++i) {
        float angle = (2.0f * M_PI / numSlices) * i;
        float x = radius * cos(angle);
        float z = radius * sin(angle);

        // Top circle vertex position
        vertices.push_back(x);
        vertices.push_back(height / 2.0f);  // y is the height
        vertices.push_back(z);

        // Color
        vertices.push_back(1.0f);  // Red
        vertices.push_back(0.0f);  // Green
        vertices.push_back(0.0f);  // Blue
        vertices.push_back(1.0f);  // Alpha
    }

    // Define the bottom circle vertices
    for (int i = 0; i < numSlices; ++i) {
        float angle = (2.0f * M_PI / numSlices) * i;
        float x = radius * cos(angle);
        float z = radius * sin(angle);

        // Bottom circle vertex position
        vertices.push_back(x);
        vertices.push_back(-height / 2.0f);  // y is the negative height
        vertices.push_back(z);

        // Color
        vertices.push_back(0.0f);  // Red
        vertices.push_back(0.0f);  // Green
        vertices.push_back(1.0f);  // Blue
        vertices.push_back(1.0f);  // Alpha
    }

    // Create indices for the top and bottom circles
    for (int i = 0; i < numSlices; ++i) {
        // Top circle indices
        indices.push_back(i);
        indices.push_back((i + 1) % numSlices);
        indices.push_back(numSlices + ((i + 1) % numSlices));

        indices.push_back(i);
        indices.push_back(numSlices + ((i + 1) % numSlices));
        indices.push_back(numSlices + i);

        // Bottom circle indices
        indices.push_back(numSlices + i);
        indices.push_back(numSlices + ((i + 1) % numSlices));
        indices.push_back((i + 1) % numSlices);

        indices.push_back(i);
        indices.push_back(numSlices + i);
        indices.push_back((i + 1) % numSlices);
    }

    // Generate and bind VAO and VBO for the vertices and indices
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), vertices.data(), GL_STATIC_DRAW);

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLushort), indices.data(), GL_STATIC_DRAW);

    // Define vertex attribute pointers for positions and colors
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Unbind
    glBindVertexArray(0);
}

void CreatePyramid(GLMesh& mesh, float baseSize, float height) {
    // Pyramid vertices (base and top)
    GLfloat verts[] = {
        // Base vertices
        -baseSize / 2.0f, 0.0f, -baseSize / 2.0f, 1.0f, 0.0f, 0.0f, 1.0f, // Base left back (Red)
         baseSize / 2.0f, 0.0f, -baseSize / 2.0f, 0.0f, 1.0f, 0.0f, 1.0f, // Base right back (Green)
         baseSize / 2.0f, 0.0f,  baseSize / 2.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Base right front (Blue)
        -baseSize / 2.0f, 0.0f,  baseSize / 2.0f, 1.0f, 1.0f, 0.0f, 1.0f, // Base left front (Yellow)
        // Top vertex 
         0.0f, height, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, // Top (Red)
    };

    // Pyramid indices for 4 triangles
    GLushort indices[] = {
        0, 1, 4, // Side 1
        1, 2, 4, // Side 2
        2, 3, 4, // Side 3
        3, 0, 4  // Side 4
    };

    // Generate and bind the Vertex Array Object
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Generate two buffers, one for the vertex positions and one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Define the position and color attribute pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Unbind the VAO
    glBindVertexArray(0);
}

void CreatePlane(GLMesh& mesh) {
    GLfloat planeVertices[] = {
        // Positions          // Texture Coords
        -5.0f, 0.0f,  5.0f,   0.0f, 1.0f, // Top Left
         5.0f, 0.0f,  5.0f,   1.0f, 1.0f, // Top Right
        -5.0f, 0.0f, -5.0f,   0.0f, 0.0f, // Bottom Left
         5.0f, 0.0f, -5.0f,   1.0f, 0.0f  // Bottom Right
    };

    GLushort planeIndices[] = {
        0, 1, 2, // First triangle
        1, 3, 2  // Second triangle
    };

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);

    mesh.nIndices = sizeof(planeIndices) / sizeof(planeIndices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(planeIndices), planeIndices, GL_STATIC_DRAW);

    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    // Texture coordinate attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

void UDestroyTexture(GLuint textureId)
{
    glDeleteTextures(1, &textureId);
}

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

void CreateSphere(GLMesh& mesh, float radius, int numSectors, int numStacks) {
    std::vector<GLfloat> vertices;
    std::vector<GLushort> indices;

    float x, y, z, xy;                              // vertex position
    float nx, ny, nz, lengthInv = 1.0f / radius;    // vertex normal
    float s, t;                                     // vertex texCoord

    float sectorStep = 2 * M_PI / numSectors;
    float stackStep = M_PI / numStacks;
    float sectorAngle, stackAngle;

    for (int i = 0; i <= numStacks; ++i) {
        stackAngle = M_PI / 2 - i * stackStep;        // starting from pi/2 to -pi/2
        xy = radius * cosf(stackAngle);               // r * cos(u)
        z = radius * sinf(stackAngle);                // r * sin(u)

        for (int j = 0; j <= numSectors; ++j) {
            sectorAngle = j * sectorStep;           // starting from 0 to 2pi

            // Vertex position (x, y, z)
            x = xy * cosf(sectorAngle);             // r * cos(u) * cos(v)
            y = xy * sinf(sectorAngle);             // r * cos(u) * sin(v)
            vertices.push_back(x);
            vertices.push_back(y);
            vertices.push_back(z);

            // Normalized vertex normal (nx, ny, nz)
            nx = x * lengthInv;
            ny = y * lengthInv;
            nz = z * lengthInv;
            vertices.push_back(nx);
            vertices.push_back(ny);
            vertices.push_back(nz);

            // Vertex tex coords (s, t) range between [0, 1]
            s = (float)j / numSectors;
            t = (float)i / numStacks;
            vertices.push_back(s);
            vertices.push_back(t);
        }
    }

    // Generate indices
    int k1, k2;
    for (int i = 0; i < numStacks; ++i) {
        k1 = i * (numSectors + 1);     // beginning of current stack
        k2 = k1 + numSectors + 1;      // beginning of next stack

        for (int j = 0; j < numSectors; ++j, ++k1, ++k2) {
            // 2 triangles per sector excluding 1st and last stacks
            // k1 => k2 => k1+1
            if (i != 0) {
                indices.push_back(k1);
                indices.push_back(k2);
                indices.push_back(k1 + 1);
            }

            // k1+1 => k2 => k2+1
            if (i != (numStacks - 1)) {
                indices.push_back(k1 + 1);
                indices.push_back(k2);
                indices.push_back(k2 + 1);
            }
        }
    }

    // Generate and bind VAO and VBO for the vertices and indices
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(GLfloat), vertices.data(), GL_STATIC_DRAW);

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLushort), indices.data(), GL_STATIC_DRAW);

    // Vertex positions
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);
    // Vertex normals
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);
    // Vertex texture coords
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    // Unbind VAO
    glBindVertexArray(0);
}

void CreateCube(GLMesh& mesh) {
    GLfloat vertices[] = {
        // Positions           // Texture Coords (Optional) // Normals
        -0.5f, -0.5f, -0.5f,   0.0f, 0.0f,                  -1.0f, -1.0f, -1.0f,
         0.5f, -0.5f, -0.5f,   1.0f, 0.0f,                   1.0f, -1.0f, -1.0f,
         0.5f,  0.5f, -0.5f,   1.0f, 1.0f,                   1.0f,  1.0f, -1.0f,
        -0.5f,  0.5f, -0.5f,   0.0f, 1.0f,                  -1.0f,  1.0f, -1.0f,
        -0.5f, -0.5f,  0.5f,   0.0f, 0.0f,                  -1.0f, -1.0f,  1.0f,
         0.5f, -0.5f,  0.5f,   1.0f, 0.0f,                   1.0f, -1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,   1.0f, 1.0f,                   1.0f,  1.0f,  1.0f,
        -0.5f,  0.5f,  0.5f,   0.0f, 1.0f,                  -1.0f,  1.0f,  1.0f,
    };

    GLushort indices[] = {
        0, 1, 2, 0, 2, 3,       // Front face
        1, 5, 6, 1, 6, 2,       // Right face
        5, 4, 7, 5, 7, 6,       // Back face
        4, 0, 3, 4, 3, 7,       // Left face
        0, 1, 5, 0, 5, 4,       // Bottom face
        3, 2, 6, 3, 6, 7        // Top face
    };

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);

    // Texture coordinate attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);

    // Normal attribute (for lighting)
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(5 * sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);
}

